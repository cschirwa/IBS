package com.kt.ibs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IbsApplication {

	public static void main(String[] args) {
		SpringApplication.run(IbsApplication.class, args);
	}

}
